# Custom Dashactyl

This is a dashactyl client panel customised for dynox

Made by [Tovade](https://tovade.xyz)

# Upcoming features

see `TODO.md` for upcoming features that are planned to come
