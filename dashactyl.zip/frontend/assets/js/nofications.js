function notificationCounter() {
    counter += 1;
    document.getElementById("NotificationBadge").innerHTML = counter;
}

const counter = 0;