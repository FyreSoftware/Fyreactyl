document.onkeydown = function (e) {
  if (event.keyCode == 123) {
    return (document.location = "https://www.youtube.com/watch?v=dQw4w9WgXcQ");
  }
  if (e.ctrlKey && e.shiftKey && e.keyCode == "I".charCodeAt(0)) {
    return (document.location = "https://www.youtube.com/watch?v=dQw4w9WgXcQ");
  }
  if (e.ctrlKey && e.shiftKey && e.keyCode == "C".charCodeAt(0)) {
    return (document.location = "https://www.youtube.com/watch?v=dQw4w9WgXcQ");
  }
  if (e.ctrlKey && e.shiftKey && e.keyCode == "J".charCodeAt(0)) {
    return (document.location = "https://www.youtube.com/watch?v=dQw4w9WgXcQ");
  }
  if (e.ctrlKey && e.keyCode == "U".charCodeAt(0)) {
    return (document.location = "https://www.youtube.com/watch?v=dQw4w9WgXcQ");
  }
};
document.addEventListener("contextmenu", function (e) {
  e.preventDefault();
  return (document.location = "https://www.youtube.com/watch?v=dQw4w9WgXcQ");
});
